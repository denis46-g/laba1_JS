import {Cache} from './cache'
const cache = new Cache();