class Cache{
    constructor(key,value,request_number = 1){
        this._data = [[key,value,request_number]];
    }
    addValue(key,value,request_number = 1){
        this._data.push([key,value,request_number]);
    }
    getValueByKey(key){
        let i=0;
        for(let pair of this._data){
            if(pair[0]==key){
                if(pair[2]>0){
                    this._data[i][2]--;
                    return pair[1];
                }
                else
                    return null;
            }
            i++;
        }
        return null;
    }
    getStatistics(){
        for(let i = 0; i < this._data.length; i++)
            if(this._data[i][2] > 0)
                this._data[i][2]--;
            else
                this._data[i]=null;
        return this._data;
    }
}
export {Cache}