import {Cache} from "../src/cache";

/*test('it fails', () => {
    expect(false).toBe(true);
});*/

test('Constructor works successfully', () => {
    let cache = new Cache("students", 25, 100);
    expect(cache._data).toEqual([["students", 25, 100]]);
});

test('New pair key-value is added to cache successfully ', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    expect(cache._data).toEqual([["students", 25, 100],["teachers", 15, 50]]);
});

test('First pair key-value in constructor without request_number makes request number equal 1 successfully ', () => {
    let cache = new Cache("student", 1);
    expect(cache._data).toEqual([["student", 1, 1]]);
});

test('New pair key-value by adding new pair without request_number makes request number equal 1 successfully ', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("new students", 1);
    expect(cache._data[1]).toEqual(["new students", 1, 1]);
});

test('getValueByKey with existing key works successfully', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    cache.addValue("new students", 5);
    let count_teachers = cache.getValueByKey("teachers");
    expect(count_teachers).toEqual(15);
});

test('getValueByKey with existing key reduces request number by 1', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    cache.addValue("new students", 5);
    cache.getValueByKey("students");
    expect(cache._data[0][2]).toEqual(99);
});

test('getValueByKey with unexisting key works successfully', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    cache.addValue("new students", 5);
    let count_guards = cache.getValueByKey("guards");
    expect(count_guards).toBeNull();
});

test('If request number equal 0 then getValueByKey returns null successfully', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    cache.addValue("new students", 5, 0);
    let count_new_students = cache.getValueByKey("new students");
    expect(count_new_students).toBeNull();
});

test('getStatistics works successfully', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    cache.addValue("new students", 7, 20);
    let stat = cache.getStatistics();
    expect(stat).toEqual([["students", 25, 99],["teachers", 15, 49],["new students", 7, 19]]);
});

test('If request number equal 0 then getStatistics returns in this pair null successfully', () => {
    let cache = new Cache("students", 25, 100);
    cache.addValue("teachers", 15, 50);
    cache.addValue("new students", 7, 0);
    let stat = cache.getStatistics();
    expect(stat).toEqual([["students", 25, 99],["teachers", 15, 49],null]);
});



